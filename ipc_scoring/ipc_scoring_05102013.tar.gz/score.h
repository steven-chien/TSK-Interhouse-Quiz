#ifndef _SCORE_H_
#define _SCORE_H_
 class Score{
     private: 
	 int score123[6];
	
     public:
         Score(int initscore);
	 void add(int house, int add);
	 void minus(int house, int minus);
	 void update(int house, int newscore);
	 int getscore(int house);
         void scoring2();
};
 #endif
